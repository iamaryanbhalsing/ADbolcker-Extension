"use strict";

importScripts(
  "./shared/pf.js",
  "./background/main.js"
)

const DEFAULT_SETTINGS = {
  masterEnabled: true,
  videoAds: true,
  overlayAds: true,
  homepageBanner: true,
  feedSponsoredCards: true,
  searchAds: true,
  sidebarAds: true,
  shortsAds: true,
  merchPromos: true
};

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.storage.sync.set({ settings: DEFAULT_SETTINGS });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'settingsChanged') {
    chrome.tabs.query({ url: '*://*.youtube.com/*' }, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, message).catch(() => {});
      });
    });
  }
});
