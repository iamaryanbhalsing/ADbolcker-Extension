setInterval(() => {
    let page = window.location.href

    if (page.includes("hotstar.com")) {
        if (had && had.checkVisibility()) {
            let hvid = had.querySelector("video")
            if (hvid) {
                hvid.currentTime = isNaN(hvid.duration) ? 0 : hvid.duration
            }
        }
    }
}, 250)
