"use strict";

const SETTING_KEYS = [
  'videoAds', 'overlayAds', 'homepageBanner', 'feedSponsoredCards',
  'searchAds', 'sidebarAds', 'shortsAds', 'merchPromos'
];

const DEFAULT_SETTINGS = { masterEnabled: true };
SETTING_KEYS.forEach(k => DEFAULT_SETTINGS[k] = true);

document.addEventListener('DOMContentLoaded', () => {
  const logo = document.getElementById('logo');
  const subtitle = document.getElementById('subtitle');
  const masterToggle = document.getElementById('masterToggle');
  const toggleRows = document.querySelectorAll('.toggle-row');

  logo.src = chrome.runtime.getURL('icons/icon-128.png');

  // Localize all elements with data-i18n attribute
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const msg = chrome.i18n.getMessage(el.dataset.i18n);
    if (msg) el.textContent = msg;
  });

  chrome.storage.sync.get('settings', (result) => {
    const settings = result.settings || DEFAULT_SETTINGS;
    applySettingsToUI(settings);
  });

  function applySettingsToUI(settings) {
    masterToggle.checked = settings.masterEnabled;

    toggleRows.forEach(row => {
      const key = row.dataset.key;
      const checkbox = row.querySelector('input[type="checkbox"]');
      checkbox.checked = settings[key] !== false;
      checkbox.disabled = !settings.masterEnabled;
      row.classList.toggle('disabled', !settings.masterEnabled);
    });

    updateSubtitle(settings);
  }

  function updateSubtitle(settings) {
    if (!settings.masterEnabled) {
      subtitle.textContent = chrome.i18n.getMessage('headerSubtitleDisabled');
      return;
    }

    const activeCount = SETTING_KEYS.filter(k => settings[k] !== false).length;
    if (activeCount === SETTING_KEYS.length) {
      subtitle.textContent = chrome.i18n.getMessage('headerSubtitleAllBlocked');
    } else if (activeCount === 0) {
      subtitle.textContent = chrome.i18n.getMessage('headerSubtitleNoneActive');
    } else {
      subtitle.textContent = chrome.i18n.getMessage('headerSubtitlePartialActive', [String(activeCount), String(SETTING_KEYS.length)]);
    }
  }

  function getSettingsFromUI() {
    const settings = { masterEnabled: masterToggle.checked };
    toggleRows.forEach(row => {
      const key = row.dataset.key;
      const checkbox = row.querySelector('input[type="checkbox"]');
      settings[key] = checkbox.checked;
    });
    return settings;
  }

  function saveAndBroadcast() {
    const settings = getSettingsFromUI();
    chrome.storage.sync.set({ settings });
    chrome.runtime.sendMessage({ type: 'settingsChanged', settings });
    updateSubtitle(settings);
  }

  masterToggle.addEventListener('change', () => {
    const enabled = masterToggle.checked;
    toggleRows.forEach(row => {
      const checkbox = row.querySelector('input[type="checkbox"]');
      checkbox.disabled = !enabled;
      row.classList.toggle('disabled', !enabled);
    });
    saveAndBroadcast();
  });

  toggleRows.forEach(row => {
    const checkbox = row.querySelector('input[type="checkbox"]');
    checkbox.addEventListener('change', saveAndBroadcast);
  });
});
