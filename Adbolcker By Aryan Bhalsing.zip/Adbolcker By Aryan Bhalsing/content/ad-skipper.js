"use strict";

(function adSkipper() {
  let isAdPlaying = false;
  let wasMuted = false;

  const SKIP_SELECTORS = [
    '.ytp-ad-skip-button',
    '.ytp-ad-skip-button-modern',
    '.ytp-skip-ad-button',
    'button.ytp-ad-skip-button',
    'button.ytp-ad-skip-button-modern',
    '.ytp-ad-skip-button-container button',
  ];

  function isVideoAdsEnabled() {
    const settings = window.__ytAdBlockSettings;
    if (!settings) return true;
    return settings.masterEnabled && settings.videoAds !== false;
  }

  function getPlayer() {
    return document.getElementById('movie_player');
  }

  function getVideo() {
    const player = getPlayer();
    return player ? player.querySelector('video') : null;
  }

  function isAdShowing() {
    const player = getPlayer();
    if (!player) return false;
    return player.classList.contains('ad-showing') ||
           player.classList.contains('ad-interrupting') ||
           !!player.querySelector('.ytp-ad-player-overlay-layout');
  }

  function tryClickSkip() {
    for (const selector of SKIP_SELECTORS) {
      const btn = document.querySelector(selector);
      if (btn && btn.offsetParent !== null) {
        btn.click();
        return true;
      }
    }
    return false;
  }

  function fastForwardAd() {
    const video = getVideo();
    if (video && video.duration && isFinite(video.duration)) {
      video.currentTime = video.duration;
    }
  }

  function muteAd() {
    const video = getVideo();
    if (video && !isAdPlaying) {
      wasMuted = video.muted;
      video.muted = true;
    }
  }

  function restoreMute() {
    const video = getVideo();
    if (video) {
      video.muted = wasMuted;
    }
  }

  function handleAd() {
    if (!isVideoAdsEnabled()) {
      if (isAdPlaying) {
        isAdPlaying = false;
        restoreMute();
      }
      return;
    }

    if (!isAdShowing()) {
      if (isAdPlaying) {
        isAdPlaying = false;
        restoreMute();
      }
      return;
    }

    if (!isAdPlaying) {
      isAdPlaying = true;
      muteAd();
    }

    if (tryClickSkip()) return;
    fastForwardAd();
  }

  setInterval(handleAd, 500);

  function observePlayer() {
    const player = getPlayer();
    if (!player) {
      setTimeout(observePlayer, 1000);
      return;
    }

    const observer = new MutationObserver(() => {
      handleAd();
    });

    observer.observe(player, {
      attributes: true,
      attributeFilter: ['class'],
      childList: true,
      subtree: true,
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', observePlayer);
  } else {
    observePlayer();
  }
})();
