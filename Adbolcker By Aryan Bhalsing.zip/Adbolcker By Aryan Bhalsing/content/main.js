"use strict";

timeout('[native code]', '17000', '0.001')

// --- JSON Prune: Fetch & XHR responses ---
// API pruning runs unconditionally (intercepts at JS level, cannot be toggled after injection).

JPFR('playerAds adPlacements adSlots playerResponse.playerAds playerResponse.adPlacements playerResponse.adSlots [].playerResponse.adPlacements [].playerResponse.playerAds [].playerResponse.adSlots', '', 'propsToMatch', '/player?')
JPXR('playerAds adPlacements adSlots playerResponse.playerAds playerResponse.adPlacements playerResponse.adSlots [].playerResponse.adPlacements [].playerResponse.playerAds [].playerResponse.adSlots', '', 'propsToMatch', '/player?')

JPFR('playerAds adPlacements adSlots playerResponse.playerAds playerResponse.adPlacements playerResponse.adSlots [].playerResponse.adPlacements [].playerResponse.playerAds [].playerResponse.adSlots', '', 'propsToMatch', '/get_watch')
JPXR('playerAds adPlacements adSlots playerResponse.playerAds playerResponse.adPlacements playerResponse.adSlots [].playerResponse.adPlacements [].playerResponse.playerAds [].playerResponse.adSlots', '', 'propsToMatch', '/get_watch')

JPFR('playerAds adPlacements adSlots', '', 'propsToMatch', '/get_midroll_info')
JPXR('playerAds adPlacements adSlots', '', 'propsToMatch', '/get_midroll_info')

RXRC('/"adPlacements.*?([A-Z]"\\}|"\\}{2,4})\\}\\],/', '', '/playlist\\?list=|player\\?|get_watch|watch\\?[tv]=|youtubei\\/v1\\/player/')
RXRC('/"adPlacements.*?("adSlots"|"adBreakHeartbeatParams")/gms', '$1', '/youtubei\\/v1\\/player|get_watch/')
RXRC('/"adSlots.*?("adBreakHeartbeatParams")/gms', '$1', '/youtubei\\/v1\\/player|get_watch/')

RFRC('/"adPlacements.*?([A-Z]"\\}|"\\}{2,4})\\}\\],/', '', '/player\\?|get_watch/')
RFRC('/"adSlots.*?\\}\\}\\],"adBreakHeartbeatParams/', '"adBreakHeartbeatParams', '/player\\?|get_watch/')

DC('ytInitialPlayerResponse.playerAds', 'undefined')
DC('ytInitialPlayerResponse.adPlacements', 'undefined')
DC('ytInitialPlayerResponse.adSlots', 'undefined')
DC('playerResponse.adPlacements', 'undefined')
DC('playerResponse.adSlots', 'undefined')
DC('playerResponse.playerAds', 'undefined')

JPFR('playerAds adPlacements adSlots playerResponse.playerAds playerResponse.adPlacements playerResponse.adSlots', '', 'propsToMatch', '/playlist?')
JPFR('reelWatchSequenceResponse.entries.[-].command.reelWatchEndpoint.adClientParams.isAd entries.[-].command.reelWatchEndpoint.adClientParams.isAd', '', 'propsToMatch', 'url:/reel_watch_sequence?')

// --- Selector groups mapped to setting keys ---
const SELECTOR_GROUPS = {
  videoAds: [
    ".ytp-ad-module",
    ".ytp-ad-player-overlay-layout",
    ".ytp-ad-action-interstitial-background-container",
    ".ytp-ad-action-interstitial-slot",
    ".ytp-ad-progress",
    ".ytp-ad-progress-list"
  ],
  overlayAds: [
    ".ytp-ad-image-overlay",
    ".ytp-ad-overlay-container",
    ".ytp-paid-content-overlay",
    "ytd-action-companion-ad-renderer",
    "ytd-companion-slot-renderer",
    ".ytp-suggested-action > .ytp-suggested-action-badge"
  ],
  homepageBanner: [
    "#masthead-ad",
    "ytd-video-masthead-ad-v3-renderer",
    "ytd-video-masthead-ad-advertiser-info-renderer",
    "ytd-page-top-ad-layout-renderer",
    "ytd-banner-promo-renderer"
  ],
  feedSponsoredCards: [
    "ytd-rich-item-renderer:has(> #content > ytd-ad-slot-renderer)",
    "ytd-in-feed-ad-layout-renderer",
    ".ytd-rich-item-renderer.style-scope > .ytd-rich-item-renderer > .ytd-ad-slot-renderer.style-scope",
    ".grid.ytd-browse > #primary > .style-scope > .ytd-rich-grid-renderer > .ytd-rich-grid-renderer > .ytd-ad-slot-renderer"
  ],
  searchAds: [
    "ytd-search-pyv-renderer",
    "ytd-promoted-sparkles-text-search-renderer",
    "ytd-promoted-sparkles-web-renderer",
    "ytd-item-section-renderer > .ytd-item-section-renderer > ytd-ad-slot-renderer.style-scope"
  ],
  sidebarAds: [
    "#player-ads ytd-ad-slot-renderer",
    ".ytd-watch-flexy > .ytd-watch-next-secondary-results-renderer > ytd-ad-slot-renderer.ytd-watch-next-secondary-results-renderer",
    "[class*=\"ytd-display-ad-\"]",
    "[layout*=\"display-ad-\"]",
    "ytd-display-ad-renderer",
    "ytd-compact-promoted-video-renderer"
  ],
  shortsAds: [
    "ytd-reel-video-renderer:has(ytd-ad-slot-renderer)",
    "#shorts-inner-container > .ytd-shorts:has(> .ytd-reel-video-renderer > ytd-ad-slot-renderer)",
    "YTM-PROMOTED-VIDEO-RENDERER",
    "reels-ad-metadata-view-model"
  ],
  merchPromos: [
    ".ytd-watch-flexy > ytd-merch-shelf-renderer > #main.ytd-merch-shelf-renderer",
    "ytd-single-option-survey-renderer",
    "tp-yt-paper-toast",
    "ytd-ads-engagement-panel-content-renderer"
  ]
};

const BLOCK_CSS =
  '{display:none !important; visibility:hidden !important; opacity:0 !important;' +
  'position:absolute !important; width:0px !important; height:0px !important;}';

function addElementToHead(element) {
  if (document.head) {
    document.head.prepend(element);
  } else {
    window.setTimeout(() => addElementToHead(element), 10);
  }
}

const style = document.createElement("style");
style.id = "yt-blacklist-styles";
addElementToHead(style);

function buildSelectorString(settings) {
  const selectors = [];
  for (const key in SELECTOR_GROUPS) {
    if (settings.masterEnabled && settings[key] !== false) {
      selectors.push(...SELECTOR_GROUPS[key]);
    }
  }
  return selectors;
}

function applySettings(settings) {
  const selectors = buildSelectorString(settings);
  if (selectors.length > 0) {
    const selectorStr = selectors.join(", ");
    style.textContent = `${selectorStr} ${BLOCK_CSS}`;
    startObserver(selectorStr);
  } else {
    style.textContent = '';
    stopObserver();
  }

  // Expose settings globally so ad-skipper.js can read them
  window.__ytAdBlockSettings = settings;
}

// --- MutationObserver for dynamically added ad elements ---
let observer = null;

function startObserver(selectorString) {
  stopObserver();

  const blockElement = elem => elem && elem.setAttribute("style",
    "display:none !important; visibility:hidden !important; opacity:0 !important;" +
    "position:absolute !important; width:0px !important; height:0px !important;");

  const handleNodes = nodes => {
    for (const node of nodes) {
      if (node.nodeType !== Node.ELEMENT_NODE) continue;
      if (node.matches(selectorString)) {
        blockElement(node);
      }
      node.querySelectorAll(selectorString).forEach(blockElement);
    }
  };

  observer = new MutationObserver(muts => {
    for (const mut of muts) {
      if (mut.addedNodes.length) {
        handleNodes(mut.addedNodes);
      }
    }
  });

  observer.observe(document.documentElement, { childList: true, subtree: true });
}

function stopObserver() {
  if (observer) {
    observer.disconnect();
    observer = null;
  }
}

// --- Listen for settings from ISOLATED world via postMessage ---
window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  if (event.data?.type === '__ytAdBlock_settings') {
    applySettings(event.data.settings);
  }
});

// Apply all-enabled defaults immediately (before isolated.js sends settings)
applySettings({
  masterEnabled: true,
  videoAds: true, overlayAds: true, homepageBanner: true,
  feedSponsoredCards: true, searchAds: true, sidebarAds: true,
  shortsAds: true, merchPromos: true
});
