"use strict";

const timeout = (funcMatcher = '', delayMatcher = '', boostRatio = '') => {
    if (typeof funcMatcher !== 'string') {
        return
    }
    const safeEnv = safeSelf()
    const regexNeedle = safeEnv.patternToRegex(funcMatcher)

    let delay = delayMatcher !== '*' ? parseInt(delayMatcher, 10) : -1

    if (isNaN(delay) || !isFinite(delay)) {
        delay = 1000
    }

    let boost = parseFloat(boostRatio)

    boost = !isNaN(boost) && isFinite(boost) ? Math.min(Math.max(boost, 0.001), 50) : 0.05

    self.setTimeout = new Proxy(self.setTimeout, {
        apply(target, thisArg, args) {
            const [callbackFunc, delayTime] = args

            if ((delay === -1 || delayTime === delay) && regexNeedle.test(callbackFunc.toString())) {
                args[1] = delayTime * boost
            }

            return target.apply(thisArg, args)
        }
    })
}

const generateExceptionToken = () => {
    const safeEnv = safeSelf()
    const token = String.fromCharCode(Date.now() % 26 + 97) + safeEnv.Math_floor(safeEnv.Math_random() * 982451653 + 982451653).toString(36)
    const originalOnError = globalThis.onerror

    globalThis.onerror = (msg, ...args) => {
        if (typeof msg === 'string' && msg.includes(token)) {
            return true
        }
        return originalOnError?.call(this, msg, ...args)
    }
    return token
}



function JPXR(prunePaths = '', needlePaths = '', ...extraArgs) {
    const safe = safeSelf()
    const xhrDetailsMap = new WeakMap()
    const additionalArgs = safe.getExtraArgs(extraArgs, 2)
    const propMatchers = createPropertyMatchMap(additionalArgs.propsToMatch, 'url')
    const stackMatcher = safe.initPattern(additionalArgs.stackToMatch || '', {
        canNegate: true
    })


    self.XMLHttpRequest = class extends self.XMLHttpRequest {
        open(method, url) {
            const xhrDetails = {
                method,
                url
            }
            let matchOutcome = 'match'
            if (propMatchers.size !== 0 && !doesObjectMatchProperties(propMatchers, xhrDetails)) {
                matchOutcome = 'nomatch'
            }
            if (matchOutcome === 'match') {
                xhrDetailsMap.set(this, xhrDetails)
            }
            super.open(method, url)
        }

        get response() {
            const originalResponse = super.response
            const xhrDetails = xhrDetailsMap.get(this)
            if (!xhrDetails) {
                return originalResponse
            }
            const responseLength = typeof originalResponse === 'string' ? originalResponse.length : undefined
            if (xhrDetails.lastResponseLength !== responseLength) {
                xhrDetails.response = undefined
                xhrDetails.lastResponseLength = responseLength
            }
            if (xhrDetails.response !== undefined) {
                return xhrDetails.response
            }
            let parsedResponse
            if (typeof originalResponse === 'object') {
                parsedResponse = originalResponse
            } else if (typeof originalResponse === 'string') {
                try {
                    parsedResponse = safe.JSON_parse(originalResponse)
                } catch (error) { }
            }
            if (typeof parsedResponse !== 'object') {
                xhrDetails.response = originalResponse
                return originalResponse
            }
            const prunedResponse = pruneObject(parsedResponse, prunePaths, needlePaths, stackMatcher)
            if (typeof prunedResponse === 'object') {
                xhrDetails.response = typeof originalResponse === 'string' ? safe.JSON_stringify(prunedResponse) : prunedResponse
            } else {
                xhrDetails.response = originalResponse
            }
            return xhrDetails.response
        }
        get responseText() {
            const {
                response
            } = this
            return typeof response !== 'string' ? super.responseText : response
        }
    }
}


// function jsonPruneXhrResponse(prunePaths = '', needlePaths = '', ...extraArgs) {
//     const safe = safeSelf();
//     const xhrDetailsMap = new WeakMap();
//     const additionalArgs = safe.getExtraArgs(extraArgs, 2);
//     const propMatchers = createPropertyMatchMap(additionalArgs.propsToMatch, 'url');
//     const stackMatcher = safe.initPattern(additionalArgs.stackToMatch || '', {
//       canNegate: true
//     });
//     self.XMLHttpRequest = class extends self.XMLHttpRequest {
//       open(method, url) {
//         const xhrDetails = {
//           method,
//           url
//         };
//         let matchOutcome = 'match';
//         if (propMatchers.size !== 0 && !doesObjectMatchProperties(propMatchers, xhrDetails)) {
//           matchOutcome = 'nomatch';
//         }
//         if (matchOutcome === 'match') {
//           xhrDetailsMap.set(this, xhrDetails);
//         }
//         super.open(method, url);
//       }
//       get response() {
//         const originalResponse = super.response;
//         const xhrDetails = xhrDetailsMap.get(this);
//         if (!xhrDetails) {
//           return originalResponse;
//         }
//         const responseLength = typeof originalResponse === 'string' ? originalResponse.length : undefined;
//         if (xhrDetails.lastResponseLength !== responseLength) {
//           xhrDetails.response = undefined;
//           xhrDetails.lastResponseLength = responseLength;
//         }
//         if (xhrDetails.response !== undefined) {
//           return xhrDetails.response;
//         }
//         let parsedResponse;
//         if (typeof originalResponse === 'object') {
//           parsedResponse = originalResponse;
//         } else if (typeof originalResponse === 'string') {
//           try {
//             parsedResponse = safe.JSON_parse(originalResponse);
//           } catch (error) {}
//         }
//         if (typeof parsedResponse !== 'object') {
//           xhrDetails.response = originalResponse;
//           return originalResponse;
//         }
//         const prunedResponse = pruneObject(parsedResponse, prunePaths, needlePaths, stackMatcher);
//         if (typeof prunedResponse === 'object') {
//           xhrDetails.response = typeof originalResponse === 'string' ? safe.JSON_stringify(prunedResponse) : prunedResponse;
//         } else {
//           xhrDetails.response = originalResponse;
//         }
//         return xhrDetails.response;
//       }
//       get responseText() {
//         const {
//           response
//         } = this;
//         return typeof response !== 'string' ? super.responseText : response;
//       }
//     };
//   }

const doesObjectMatchProperties = (propNeedles, ...objs) => {
    const self = doesObjectMatchProperties

    if (self.extractProperties === undefined) {
        self.extractProperties = (src, des, props) => {
            for (const p of props) {
                const v = src[p]
                if (v === undefined) {
                    continue
                }
                des[p] = src[p]
            }
        }
    }

    const safe = safeSelf()
    const haystack = {}
    const props = safe.Array_from(propNeedles.keys())

    for (const obj of objs) {
        if (obj instanceof Object === false) {
            continue
        }
        self.extractProperties(obj, haystack, props)
    }

    for (const [prop, details] of propNeedles) {
        let value = haystack[prop]

        if (value === undefined) {
            continue
        }

        if (typeof value !== 'string') {
            try {
                value = safe.JSON_stringify(value)
            } catch (ex) { }
            if (typeof value !== 'string') {
                continue
            }
        }

        if (safe.testPattern(details, value)) {
            continue
        }
        return false
    }
    return true
}


const matchesStackTrace = (needleDetails) => {
    const safe = safeSelf()
    const exceptionToken = generateExceptionToken()
    const error = new safe.Error(exceptionToken)
    const docURL = new URL(self.location.href)
    docURL.hash = ''
    const reLine = /(.*?@)?(\S+)(:\d+):\d+\)?$/
    const lines = []

    for (let line of error.stack?.split(/[\n\r]+/) ?? []) {
        if (line.includes(exceptionToken)) {
            continue
        }

        line = line.trim()
        const match = safe.RegExp_exec.call(reLine, line)

        if (match === null) {
            continue
        }

        let url = match[2]

        if (url.startsWith('(')) {
            url = url.slice(1)
        }

        if (url === docURL.href) {
            url = 'inlineScript'
        } else if (url.startsWith('<anonymous>')) {
            url = 'injectedScript'
        }

        let fn = match[1] !== undefined ? match[1].slice(0, -1) : line.slice(0, match.index).trim()

        if (fn.startsWith('at')) {
            fn = fn.slice(2).trim()
        }

        const rowcol = match[3]
        lines.push(` ${`${fn} ${url}${rowcol}:1`.trim()}`)
    }

    lines[0] = `stackDepth:${lines.length - 1}`
    const stack = lines.join('\t')
    return needleDetails.matchAll !== true && safe.testPattern(needleDetails.pattern, stack)
}


const findObjectOwner = (root, path, prune = false) => {
    let currentOwner = root
    let remainingPath = path

    while (true) {

        if (typeof currentOwner !== 'object' || currentOwner === null) {
            return false
        }

        const dotPosition = remainingPath.indexOf('.')

        if (dotPosition === -1) {
            if (!prune) {
                return Object.prototype.hasOwnProperty.call(currentOwner, remainingPath)
            }
            let isModified = false

            if (remainingPath === '*') {
                for (const key in currentOwner) {
                    if (!Object.prototype.hasOwnProperty.call(currentOwner, key)) {
                        continue
                    }
                    delete currentOwner[key]
                    isModified = true
                }
            } else if (Object.prototype.hasOwnProperty.call(currentOwner, remainingPath)) {
                delete currentOwner[remainingPath]
                isModified = true
            }
            return isModified
        }

        const currentProp = remainingPath.slice(0, dotPosition)
        const nextPath = remainingPath.slice(dotPosition + 1)
        let isFound = false

        if (currentProp === '[-]' && Array.isArray(currentOwner)) {
            let i = currentOwner.length
            while (i--) {
                if (!findObjectOwner(currentOwner[i], nextPath)) {
                    continue
                }
                currentOwner.splice(i, 1)
                isFound = true
            }
            return isFound
        }

        if (currentProp === '{-}' && currentOwner instanceof Object) {
            for (const key of Object.keys(currentOwner)) {
                if (!findObjectOwner(currentOwner[key], nextPath)) {
                    continue
                }
                delete currentOwner[key]
                isFound = true
            }
            return isFound
        }

        if (currentProp === '[]' && Array.isArray(currentOwner) || currentProp === '{}' && currentOwner instanceof Object || currentProp === '*' && currentOwner instanceof Object) {
            for (const key of Object.keys(currentOwner)) {
                if (!findObjectOwner(currentOwner[key], nextPath, prune)) {
                    continue
                }
                isFound = true
            }
            return isFound
        }

        if (!Object.prototype.hasOwnProperty.call(currentOwner, currentProp)) {
            return false
        }
        currentOwner = currentOwner[currentProp]
        remainingPath = remainingPath.slice(dotPosition + 1)
    }
}

const pruneObject = (obj, rawPrunePaths, rawNeedlePaths, stackNeedleDetails) => {
    const self = pruneObject
    const prunePaths = rawPrunePaths !== '' ? rawPrunePaths.split(/ +/) : []
    const needlePaths = prunePaths.length !== 0 && rawNeedlePaths !== '' ? rawNeedlePaths.split(/ +/) : []

    if (!stackNeedleDetails.matchAll) {
        if (!matchesStackTrace(stackNeedleDetails)) {
            return
        }
    }

    if (self.mustProcess === undefined) {
        self.mustProcess = (root, needlePathsVal) => {
            for (const needlePath of needlePathsVal) {
                if (!findObjectOwner(root, needlePath)) {
                    return false
                }
            }
            return true
        }
    }

    if (prunePaths.length === 0) {
        return
    }

    let outcome = 'nomatch'

    if (self.mustProcess(obj, needlePaths)) {
        for (const path of prunePaths) {
            if (findObjectOwner(obj, path, true)) {
                outcome = 'match'
            }
        }
    }

    if (outcome === 'match') {
        return obj
    }
}

const createPropertyMatchMap = (properties, defaultProp = '') => {
    const safeEnv = safeSelf()
    const matchMap = new Map()

    if (!properties) {
        return matchMap
    }

    const patternOptions = {
        canNegate: true
    }

    for (const propertyPair of properties.split(/\s+/)) {
        const [property, pattern] = propertyPair.split(':')

        if (!property) {
            continue
        }

        if (pattern !== undefined) {
            matchMap.set(property, safeEnv.initPattern(pattern, patternOptions))
        } else if (defaultProp) {
            matchMap.set(defaultProp, safeEnv.initPattern(property, patternOptions))
        }
    }
    return matchMap
}

const RFRC = (pattern = '', replacement = '', propertiesToMatch = '', ...args) => {
    const safe = safeSelf()

    if (pattern === '*') {
        pattern = '.*'
    }
    const rePattern = safe.patternToRegex(pattern)
    const propNeedles = createPropertyMatchMap(propertiesToMatch, 'url')
    const extraArgs = safe.getExtraArgs(Array.from(args), 4)
    const reIncludes = extraArgs.includes ? safe.patternToRegex(extraArgs.includes) : null

    self.fetch = new Proxy(self.fetch, {
        apply(target, thisArg, params) {
            const fetchPromise = Reflect.apply(target, thisArg, params)
            if (pattern === '') {
                return fetchPromise
            }
            let outcome = 'match'

            if (propNeedles.size !== 0) {
                const objs = [params[0] instanceof Object ? params[0] : {
                    url: params[0]
                }]
                if (objs[0] instanceof Request) {
                    try {
                        objs[0] = safe.Request_clone.call(objs[0])
                    } catch (ex) { }
                }
                if (params[1] instanceof Object) {
                    objs.push(params[1])
                }
                if (!doesObjectMatchProperties(propNeedles, ...objs)) {
                    outcome = 'nomatch'
                }
            }

            if (outcome === 'nomatch') {
                return fetchPromise
            }

            return fetchPromise.then(responseBefore => {
                const response = responseBefore.clone()

                return response.text().then(textBefore => {
                    if (reIncludes && reIncludes.test(textBefore) === false) {
                        return responseBefore
                    }
                    const textAfter = textBefore.replace(rePattern, replacement)
                    const finalOutcome = textAfter !== textBefore ? 'match' : 'nomatch'
                    if (finalOutcome === 'nomatch') {
                        return responseBefore
                    }
                    const responseAfter = new Response(textAfter, {
                        status: responseBefore.status,
                        statusText: responseBefore.statusText,
                        headers: responseBefore.headers
                    })
                    Object.defineProperties(responseAfter, {
                        ok: {
                            value: responseBefore.ok
                        },
                        redirected: {
                            value: responseBefore.redirected
                        },
                        type: {
                            value: responseBefore.type
                        },
                        url: {
                            value: responseBefore.url
                        }
                    })
                    return responseAfter
                }).catch(() => responseBefore)
            }).catch(() => fetchPromise)
        }
    })
}


function RXRC(pattern = '', replacement = '', propsToMatch = '', ...args) {
    const safe = safeSelf()
    const xhrDetailsMap = new WeakMap()

    if (pattern === '*') {
        pattern = '.*'
    }

    const responsePatternRegex = safe.patternToRegex(pattern)
    const propertyNeedles = createPropertyMatchMap(propsToMatch, 'url')
    const extraArgs = safe.getExtraArgs(Array.from(args), 3)
    const reIncludes = extraArgs.includes ? safe.patternToRegex(extraArgs.includes) : null

    self.XMLHttpRequest = class extends self.XMLHttpRequest {
        open(method, url) {
            const currentXhr = this
            const xhrDetails = {
                method,
                url
            }

            let matchOutcome = 'match'
            if (propertyNeedles.size !== 0) {
                if (!doesObjectMatchProperties(propertyNeedles, xhrDetails)) {
                    matchOutcome = 'nomatch'
                }
            }

            if (matchOutcome === 'match') {
                xhrDetailsMap.set(currentXhr, xhrDetails)
            }

            return super.open(method, url)
        }

        get response() {
            const originalResponse = super.response
            const xhrDetails = xhrDetailsMap.get(this)
            if (xhrDetails === undefined) {
                return originalResponse
            }
            const responseLength = typeof originalResponse === 'string' ? originalResponse.length : undefined
            if (xhrDetails.lastResponseLength !== responseLength) {
                xhrDetails.response = undefined
                xhrDetails.lastResponseLength = responseLength
            }
            if (xhrDetails.response !== undefined) {
                return xhrDetails.response
            }
            if (typeof originalResponse !== 'string') {
                xhrDetails.response = originalResponse
                return originalResponse
            }
            if (reIncludes && reIncludes.test(originalResponse) === false) {
                xhrDetails.response = originalResponse
                return originalResponse
            }
            const modifiedResponse = originalResponse.replace(responsePatternRegex, replacement)
            xhrDetails.response = modifiedResponse
            return modifiedResponse
        }

        get responseText() {
            const {
                response
            } = this
            if (typeof response !== 'string') {
                return super.responseText
            }
            return response
        }
    }
}

const scheduleExecution = (action, states) => {
    const mapReadyStateToValue = (inputStates) => {
        const stateMapping = {
            loading: 1,
            interactive: 2,
            end: 2,
            '2': 2,
            complete: 3,
            idle: 3,
            '3': 3
        }

        const stateArray = Array.isArray(inputStates) ? inputStates : [inputStates]

        for (const singleState of stateArray) {
            const stateKey = `${singleState}`

            if (stateMapping[stateKey] !== undefined) {
                return stateMapping[stateKey]
            }
        }
        return 0
    }

    const targetReadyStateValue = mapReadyStateToValue(states)

    const handleStateChange = () => {
        if (mapReadyStateToValue(document.readyState) >= targetReadyStateValue) {
            action()
            safeSelf().removeEventListener('readystatechange', handleStateChange, true)
        }
    }
    if (mapReadyStateToValue(document.readyState) >= targetReadyStateValue) {
        action()
    } else {
        const safeContext = safeSelf()
        safeContext.addEventListener('readystatechange', handleStateChange, {
            capture: true
        })
    }
}

function DC(chain = '', rawValue = '', ...rest) {
    if (chain === '') {
        return
    }

    const safe = safeSelf()
    const extraArgs = safe.getExtraArgs([chain, rawValue, ...rest], 3)

    function setConstantFn(chainVal, rawVal) {
        const trappedProp = (() => {
            const pos = chainVal.lastIndexOf('.')
            return pos === -1 ? chainVal : chainVal.slice(pos + 1)
        })()

        const cloakFunction = fn => {
            safe.Object_defineProperty(fn, 'name', {
                value: trappedProp
            })
            return new Proxy(fn, {
                defineProperty(target, prop, ...args) {
                    return prop !== 'toString' ? Reflect.defineProperty(target, prop, ...args) : true
                },
                deleteProperty(target, prop) {
                    return prop !== 'toString' ? Reflect.deleteProperty(target, prop) : true
                },
                get(target, prop, ...args) {
                    return prop === 'toString' ? () => `function ${trappedProp}() { [native code] }` : Reflect.get(target, prop, ...args)
                }
            })
        }

        if (trappedProp === '') {
            return
        }

        const thisScript = document.currentScript
        let normalValue = getValidatedConstant(true, rawVal)

        if (rawVal === 'noopFunc' || rawVal === 'trueFunc' || rawVal === 'falseFunc') {
            normalValue = cloakFunction(normalValue)
        }

        let aborted = false
        const mustAbort = val => {
            if (aborted) {
                return true
            }
            aborted = val !== undefined && val !== null && normalValue !== undefined && normalValue !== null && typeof val !== typeof normalValue;
            return aborted;
        }

        const trapProperty = (owner, prop, configurable, handler) => {
            if (!handler.init(configurable ? owner[prop] : normalValue)) {
                return
            }
            const originalDescriptor = safe.Object_getOwnPropertyDescriptor(owner, prop)
            let previousGetter
            let previousSetter
            if (originalDescriptor instanceof Object) {
                owner[prop] = normalValue
                if (originalDescriptor.get instanceof Function) {
                    previousGetter = originalDescriptor.get
                }
                if (originalDescriptor.set instanceof Function) {
                    previousSetter = originalDescriptor.set
                }
            }
            try {
                safe.Object_defineProperty(owner, prop, {
                    configurable,
                    get() {
                        return previousGetter ? previousGetter() : handler.getter()
                    },
                    set(newValue) {
                        if (previousSetter) {
                            previousSetter(newValue)
                        }
                        handler.setter(newValue)
                    }
                })
            } catch (ex) { }
        }
        const trapChain = (owner, chainValue) => {
            const pos = chainValue.indexOf('.')
            if (pos === -1) {
                trapProperty(owner, chainValue, false, {
                    value: undefined,
                    init(val) {
                        if (mustAbort(val)) {
                            return false
                        }
                        this.value = val
                        return true
                    },
                    getter() {
                        return document.currentScript === thisScript ? this.value : normalValue
                    },
                    setter(newValue) {
                        if (!mustAbort(newValue)) {
                            return
                        }
                        normalValue = newValue
                    }
                })
                return
            }
            const prop = chainValue.slice(0, pos)
            const val = owner[prop]
            chainValue = chainValue.slice(pos + 1)
            if (val instanceof Object || typeof val === 'object' && val !== null) {
                trapChain(val, chainValue)
                return
            }
            trapProperty(owner, prop, true, {
                value: undefined,
                init(value) {
                    this.value = value
                    return true
                },
                getter() {
                    return this.value
                },
                setter(newValue) {
                    this.value = newValue
                    if (newValue instanceof Object) {
                        trapChain(newValue, chainValue)
                    }
                }
            })
        }
        trapChain(window, chainVal)
    }
    scheduleExecution(() => {
        setConstantFn(chain, rawValue)
    }, extraArgs.runAt ?? '')
}


const getValidatedConstant = (isTrusted, rawValue, ...additionalArgs) => {
    const safeEnv = safeSelf()
    const extraArgs = safeEnv.getExtraArgs(additionalArgs, 0)
    let constantValue

    switch (rawValue) {
        case 'undefined':
            constantValue = undefined;
            break;
        case 'false':
            constantValue = false;
            break;
        case 'true':
            constantValue = true;
            break;
        case 'null':
            constantValue = null;
            break;
        case "''":
        case '':
            constantValue = '';
            break;
        case '[]':
        case 'emptyArr':
            constantValue = [];
            break;
        case '{}':
        case 'emptyObj':
            constantValue = {};
            break;
        case 'noopFunc':
            constantValue = function () { };
            break;
        case 'trueFunc':
            constantValue = function () {
                return true;
            };
            break;
        case 'falseFunc':
            constantValue = function () {
                return false;
            };
            break;
        default:
            if (/^-?\d+$/.test(rawValue)) {
                constantValue = parseInt(rawValue, 10);
                if (isNaN(constantValue) || Math.abs(constantValue) > 0x7fff) {
                    return;
                }
            } else if (isTrusted && rawValue.startsWith('{') && rawValue.endsWith('}')) {
                try {
                    constantValue = safeEnv.JSON_parse(rawValue).value;
                } catch (ex) {
                    return
                }
            } else {
                return
            }
            break
    }

    if (extraArgs.as !== undefined) {
        switch (extraArgs.as) {
            case 'function':
                return () => constantValue;
            case 'callback':
                return () => () => constantValue;
            case 'resolved':
                return Promise.resolve(constantValue);
            case 'rejected':
                return Promise.reject(constantValue);
            default:
                break;
        }
    }

    return constantValue;
}