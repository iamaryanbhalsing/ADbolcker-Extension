"use strict";

class Main {
    async init() {
        await this.updateContentScripts()
    }

    async updateContentScripts(sitesData = {}) {
        const data = [{
            hosts: ['youtube.com', 'youtu.be', 'yt.be'],
            scripts: [
                {
                    allFrames: true,
                    id: 'yt-main',
                    js: [
                        'content/utils/safe-self.js',
                        'content/utils/prune.js',
                        'content/utils/helpers.js',
                        'content/main.js',
                        'content/ad-skipper.js'
                    ],
                    matches: ['*://*.youtube.com/*', '*://*.youtu.be/*', '*://*.yt.be/*'],
                    runAt: 'document_start',
                    world: 'MAIN'
                },
                {
                    allFrames: true,
                    id: 'yt-isolated',
                    js: ['content/isolated.js'],
                    matches: ['*://*.youtube.com/*', '*://*.youtu.be/*', '*://*.yt.be/*'],
                    runAt: 'document_start'
                }]
        }]
        const registeredScripts = await browser.scripting.getRegisteredContentScripts({
            ids: data.flatMap(({
                scripts
            }) => scripts.map(({
                id
            }) => id))
        })
        const idsToUnregister = data.filter(({
            hosts
        }) => hosts.some(h => sitesData[h])).flatMap(({
            scripts
        }) => scripts).filter(({
            id
        }) => registeredScripts.some(s => s.id === id)).map(({
            id
        }) => id)
        if (idsToUnregister.length) {
            await browser.scripting.unregisterContentScripts({
                ids: idsToUnregister
            })
        }
        const scriptsToRegister = data.flatMap(({
            scripts
        }) => scripts.filter(script => !idsToUnregister.includes(script.id) && !registeredScripts.some(s => s.id === script.id)))
        if (scriptsToRegister.length) {
            await browser.scripting.registerContentScripts(scriptsToRegister)
        }
    }
}
const main = new Main()

main.init()
